<?php 
	session_start();
    include("stallite-header.php"); 
    $det = $students->getStudentMatricNumber($student_matric_num);
    $level_name = $det['level'];
    $prog_id = $det['prog_id'];
    $dept_name = $det['dept_name'];
    $nnn = $department->getDepartmentDetailsName($dept_name);
    $dept_id = $nnn['dept_id'];
    $lel = $students->getLevelName($level_name);
    $level_id = $lel['level_id'];
?>

<div class="tg-innerbanner">
	<div class="container">
		<div class="row">
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
				<ol class="tg-breadcrumb">
					<li><a href="./">Home</a></li>
					<li><a href="my-course-registration.php">Course Registration</a></li>
					<li class="tg-active"><?php echo $stepone['surname']." ". $stepone['other_names']; ; ?>'s DASHBOARD</li>

				</ol>
			</div>
		</div>
	</div>
</div>
<main id="tg-main" class="tg-main tg-haslayout">
	<div class="container">
		<div class="row">
			<div id="tg-twocolumns" class="tg-twocolumns">
				<div class="col-xs-12 col-sm-4 col-md-3 col-lg-3">
					<?php include("stallite-side-bar.php"); ?>			
				</div>
				<div class="col-xs-12 col-sm-8 col-md-9 col-lg-9">
					<div id="tg-content" class="tg-content">
						<section class="tg-sectionspace tg-haslayout">
							<div class="tg-borderheading">
								
								<h3 align="center"><p style="color: green;"><?php  echo strtoupper($stepone['surname']." ". $stepone['other_names']. " "."Welcome to Your Dashboard.");?> </p></h3>
							</div>
							
							<form action="process-my-course-registration.php" method="post" enctype="multipart/form-data">
								<div class="tg-borderheading">
									
				                    <div class="tg-addmission tg-addmissiondetail"><?php
				                    	if($prog_id ==2){ ?>
								            <div class="col-md-12" align="center" style="margin-top: -50px;">
												<img src="../../images/form-logo.png" alt="../images/form-logo.png" style="width: 950px; height: ; ">
											</div><?php
										}else{ ?>
											<div class="col-md-12" align="center" style="margin-top: -50px;">
												<img src="../../images/afriweblogo.jpg" alt="../images/afriweblogo.jpg" style="width: 950px; height: ; " >
											</div><?php
										} ?>
										<div class="tg-pagetitle">
											<h3 align="center"><b>STUDENT COURSE FORM</b></h3>
										</div>
										<?php
						                    if((isset($_SESSION['success'])) OR ((isset($_SESSION['error'])) === true)){ ?>
						                        <div class="alert alert-info" align="center">
						                            <button class="close" data-dismiss="alert">
						                                <i class="ace-icon fa fa-times"></i>
						                            </button>
						                         <?php include("../../mgchst-administrator/includes/feed-back.php"); ?>
						                        </div><?php 
						                    }  ?>
										<div class="tg-container">
											<h3><p align="center" style="color: green">Please Click On Add Course To Register The Course.<br></p></h3><br>
											<div class="col-md-6">
		                                        <h6><B><p>Matric Number: <?php echo $student_matric_num; ?></p>
		                                         <p>Full Name: <?php echo $stepone['surname']." ". $stepone['other_names']; ?></p>
		                                        <p>Department: <?php echo $dept_name; ?></p>
		                                        <p>Programme:<?php 
		                                        	if($prog_id ==1){ 
		                                        		echo "Degree FT";
		                                        	}elseif($prog_id ==2){
		                                        		echo "Diploma";
		                                        	}else{
		                                        		echo "Degree PT";
		                                        	} ?></p>
		                                        <p>Level:<?php echo $level_name; ?></p></B></h6>
		                                    </div> <?php
	                                    	$course = $db->prepare("SELECT * FROM school_course WHERE dept_id=:dept_id ORDER BY course_title ASC ");
	                                    	$arrCo = array(':dept_id'=>$dept_id);
											$course->execute($arrCo);
											if($course->rowCount()==0){ ?>
												<p style="color: red">Your Departmental Course List is Empty, The Management Team Are Working on it, Please Check Back Again Later</p><?php
											}else{ ?>
			                                    <div class="col-md-6" >
			                                        <img src="<?php echo "../application-form/studentadmissionimages/".$details['passport_url']; ?>" style="width: 100px; height: 100px;" alt="<?php echo "$student_matric_num"; ?>" align="right">
			                                        <select class="form-control" required name="session_id">
	                                                    <option value="">-- Please Select The School Session --</option>
	                                                    <option value=""></option>
	                                                    <option value="2019/2020">2019/2020</option>
	                                                    <option value="2018/2019">2018/2019</option>
	                                                    <option value="2017/2018">2017/2018</option>
	                                                    <option value="2016/2017">2016/2017</option>
	                                                    <option value="2015/2016">2015/2016</option>
	                                                    <option value="2014/2015">2014/2015</option>
	                                               </select>
			                                    </div> 
												<table class="table table-responsive table-bordered">
													<thead>
														<th>S/N</th>
														<th>COURSE CODE</th>
														<th>COURSE TITLE</th>
														<th>COURSE UNIT</th>
														<th>COURSE STATUS</th>
														<th>OPERATION</th>
													</thead>
													<tfoot>
														<th>S/N</th>
														<th>COURSE CODE</th>
														<th>COURSE TITLE</th>
														<th>COURSE UNIT</th>
														<th>COURSE STATUS</th>
														<th>OPERATION</th>
													</tfoot><?php
													
													$count = 1;
													while($now = $course->fetch()){ ?>
														
														<tbody>
															<td><?php echo $count; ?></td>
															<td><?php echo $course_code = $now['course_code']; 
																$vode = $register->getCourseDetails($course_code); ?>	
															</td>
															<td><?php echo $vode['course_title']; ?></td>
															<td><?php echo $now['course_status']; ?></td>
															<td><?php echo $vode['course_unit']; ?></td>
															<td>
									                            <input type="checkbox" name="add_course<?php echo $count; ?>" value="1">Add Course
									                        </td>
															<input type="hidden" name="course_code<?php echo $count ?>" value="<?php echo $course_code ?>">

															<input type="hidden" name="student_matric_num" value="<?php echo $student_matric_num ?>">
															<input type="hidden" name="level_id" value="<?php echo $level_name; ?>">
															<input type="hidden" name="prog_id" value="<?php echo $prog_id; ?>">

															<input type="hidden" name="dept_name" value="<?php echo $dept_name; ?>">
														</tbody><?php
														$count++;
													}  ?>
												</table><?php
											} ?>
										</div>
									</div>
								</div>
							
							
								<div class="col-sm-12" align="center">
                                <div class="md-form-group">
                                    <input type="hidden" name="show" value="<?php echo $count; ?>">
                                    <button type="submit" class="btn btn-success">COMPLETE MY COURSE REGISTRATION</button>
                                </div>
                            </div>
                        </form>
						</section>
					</div>
				</div>
				
			</div>
		</div>
	</div>
</main>

<?php 
	include("../../inc/footer.php"); 
?>