<?php 
	session_start();
    include("stallite-header.php"); 
    $det = $students->getStudentMatricNumber($student_matric_num);
    $level_name = $det['level'];
    $prog_id = $det['prog_id'];
    $dept_name = $det['dept_name'];
    $nnn = $department->getDepartmentDetailsName($dept_name);
    $dept_id = $nnn['dept_id'];
    $lel = $students->getLevelName($level_name);
    $level_id = $lel['level_id'];
?>

<div class="tg-innerbanner">
	<div class="container">
		<div class="row">
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
				<ol class="tg-breadcrumb">
					<li><a href="./">Home</a></li>
					<li><a href="check-my-result.php">My Result</a></li>
					<li><a href="my-transcript.php">My Transcript</a></li>
					<li class="tg-active">My Results</li>

				</ol>
			</div>
		</div>
	</div>
</div>
<main id="tg-main" class="tg-main tg-haslayout">
	<div class="container">
		<div class="row">
			<div id="tg-twocolumns" class="tg-twocolumns">
				<div class="col-xs-12 col-sm-4 col-md-3 col-lg-3">
					<?php include("stallite-side-bar.php"); ?>			
				</div>
				<div class="col-xs-12 col-sm-8 col-md-9 col-lg-9">
					<div id="tg-content" class="tg-content">
						<section class="tg-sectionspace tg-haslayout">
							
							<div class="tg-borderheading">
								
			                    <div class="tg-addmission tg-addmissiondetail"><?php
			                    	if($prog_id ==2){ ?>
							            <div class="col-md-12" align="center" style="margin-top: -30px;">
											<img src="../../images/form-logo.png" alt="../images/form-logo.png" style="width: 950px; height: ; ">
										</div><?php
									}else{ ?>
										<div class="col-md-12" align="center" style="margin-top: -30px;">
											<img src="../../images/afriweblogo.jpg" alt="../images/form-logo.png" style="width: 950px; height: ; " >
										</div><?php
									} ?>
									<div class="tg-pagetitle">
										<h3 align="center"><b>STUDENT RESULT PANEL</b></h3>
									</div>
										<?php
					                    if((isset($_SESSION['success'])) OR ((isset($_SESSION['error'])) === true)){ ?>
					                        <div class="alert alert-info" align="center">
					                            <button class="close" data-dismiss="alert">
					                                <i class="ace-icon fa fa-times"></i>
					                            </button>
					                         <?php include("../../mgchst-administrator/includes/feed-back.php"); ?>
					                        </div><?php 
					                    }  ?>
									
									</div>
									<div class="col-sm-12" align="center"><?php
		                                $sess = $db->prepare("SELECT * FROM session ORDER BY session_name ASC");
		                                $sess->execute();
		                                while($jope = $sess->fetch()){  ?>
											<div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
												<article class="tg-themepost tg-eventpost">
													<div align="center">
														<img src="images/Ebooks.jpg" alt="Academic Session Name" style="width: 50px; height: 50px; ">
											    	</div>
													<div class="tg-themepostcontent">
														<div class="tg-themeposttitle">
															<p style="color: green" align="center"><strong>
																
																<?php echo  $session_nam =
																$jope['session_name']. " Session";
																$session_name = $jope['session_name']; ?>
																 </strong>		
															</p>
															
															<a href="my-session-result.php?student_matric_num=<?php echo $student_matric_num ?>&&academic_session=<?php echo $session_name; ?>" class="btn btn-success">SEE MY RESULT</a></p>
															
														</div>
														
													</div>
												</article>
											</div><?php
										} ?>
									</div>
								</div>
                        	</div>
						</section>
					</div>
				</div>
				
			</div>
		</div>
	</div>
</main>

<?php 
	include("../../inc/footer.php"); 
?>