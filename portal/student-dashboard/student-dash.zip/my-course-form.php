<?php 
	session_start();
    include("stallite-header.php"); 
    $student_matric_num = $_GET['student-matric-number'];
    $session_id = $_GET['session_identification'];
    $depo = $regid->getMyCourseList($student_matric_num, $session_id);
    $det = $students->getStudentMatricNumber($student_matric_num);
    $level_name = $det['level'];
    $prog_id = $det['prog_id'];
    $dept_name = $det['dept_name'];
    $nnn = $department->getDepartmentDetailsName($dept_name);
    $dept_id = $nnn['dept_id'];
    $lel = $students->getLevelName($level_name);
    $level_id = $lel['level_id'];

?>

<div class="tg-innerbanner">
	<div class="container">
		<div class="row">
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
				<ol class="tg-breadcrumb">
					<li><a href="./">Home</a></li>
					<li><a href="my-course-list.php?student-matric-number=<?php echo $student_matric_num?>&&session_identification=<?php echo $depo['session_id']; ?>">My Course List</a></li>
					<li><a href="my-course-registration.php">Course Registration</a></li>
					<li class="tg-active"><?php echo $stepone['surname']." ". $stepone['other_names']; ; ?>'s DASHBOARD</li>

				</ol>
			</div>
		</div>
	</div>
</div>
<main id="tg-main" class="tg-main tg-haslayout">
	<div class="container">
		<div class="row">
			<div id="tg-twocolumns" class="tg-twocolumns">
				<div class="col-xs-12 col-sm-4 col-md-3 col-lg-3">
					<?php include("stallite-side-bar.php"); ?>			
				</div>
				<div class="col-xs-12 col-sm-8 col-md-9 col-lg-9">
					<div id="tg-content" class="tg-content">
						<section class="tg-sectionspace tg-haslayout">
							<div class="tg-borderheading">
								
								<h3 align="center"><p style="color: green;"><?php  echo strtoupper($stepone['surname']." ". $stepone['other_names']. " "."Welcome to Your Dashboard.");?> </p></h3>
							</div>
								
							<div class="tg-borderheading">

			                    <div class="tg-addmission tg-addmissiondetail"><?php
			                    	if($prog_id ==2){ ?>
							            <div class="col-md-12" align="center" style="margin-top: -50px;">
											<img src="../../images/form-logo.png" alt="../images/form-logo.png" style="width: 950px; height: ; ">
										</div><?php
									}else{ ?>
										<div class="col-md-12" align="center" style="margin-top: -50px;">
											<img src="../../images/afriweblogo.jpg" alt="../images/form-logo.png" style="width: 950px; height: ; " >
										</div><?php
									} ?>
									<div class="tg-pagetitle">
										<h3 align="center"><b>STUDENT COURSE FORM</b></h3>
									</div>
									<?php
					                    if((isset($_SESSION['success'])) OR ((isset($_SESSION['error'])) === true)){ ?>
					                        <div class="alert alert-info" align="center">
					                            <button class="close" data-dismiss="alert">
					                                <i class="ace-icon fa fa-times"></i>
					                            </button>
					                         <?php include("../../mgchst-administrator/includes/feed-back.php"); ?>
					                        </div><?php 
					                    }  ?>
									<div class="tg-container">
										<h3><p align="center" style="color: green"><br></p></h3><br>
										<div class="col-md-6">
	                                        <h6><B><p>Matric Number: <?php echo $student_matric_num; ?></p>
	                                         <p>Full Name: <?php echo $stepone['surname']." ". $stepone['other_names']; ?></p>
	                                        <p>Department: <?php echo $dept_name; ?></p>
	                                        <p>Programme:<?php 
	                                        	if($prog_id ==1){ 
	                                        		echo "Degree FT";
	                                        	}elseif($prog_id ==2){
	                                        		echo "Diploma";
	                                        	}else{
	                                        		echo "Degree PT";
	                                        	} ?></p>
	                                        
	                                    	<p>Session:<?php echo $depo['session_id']; ?></p></B></h6>
	                                    </div> 
	                                    
	                                    <div class="col-md-6" >
	                                        <img src="<?php echo "../application-form/studentadmissionimages/".$details['passport_url']; ?>" style="width: 100px; height: 100px;" alt="<?php echo "$student_matric_num"; ?>" align="right">
	                                        <br><br>
                                        </div>
                                       
										<table class="table table-responsive table-bordered">
											<thead>
												<th>S/N</th>
												<th>COURSE CODE</th>
												<th>COURSE TITLE</th>
												<th>COURSE UNIT</th>
												<th>COURSE STATUS</th>
												
											</thead>
											<tfoot>
												<th>S/N</th>
												<th>COURSE CODE</th>
												<th>COURSE TITLE</th>
												<th>COURSE UNIT</th>
												<th>COURSE STATUS</th>
												
											</tfoot><?php
											$myList = $db->prepare("SELECT * FROM course_registration WHERE student_matric_num=:student_matric_num AND session_id=:session_id");
											$arrList = array(':student_matric_num'=>$student_matric_num, ':session_id'=>$session_id);
											$myList->execute($arrList);
											$count = 1;
											while($now = $myList->fetch()){ ?>
												
												<tbody>
													<td><?php echo $count; ?></td>
													<td><?php echo $course_code = $now['course_code']; 
														$vode = $register->getCourseDetails($course_code); ?>

													</td>
													<td><?php echo $vode['course_title']; ?></td>
													<?php 
													$see = $db->prepare("SELECT * FROM school_course WHERE course_code=:course_code");
													$seeArr = array(':course_code'=>$course_code);
													$see->execute($seeArr);
													$sis = $see->fetch() ?>
													
													<td><?php echo $course_unit = $vode['course_unit']; ?></td>
													<td><?php echo $sis['course_status']; ?></td>
													
													<input type="hidden" name="course_code<?php echo $count ?>" value="<?php echo $course_code ?>">

													<input type="hidden" name="student_matric_num" value="<?php echo $student_matric_num ?>">
													<input type="hidden" name="level_id" value="<?php echo $level_name; ?>">
													<input type="hidden" name="prog_id" value="<?php echo $prog_id; ?>">

													<input type="hidden" name="dept_name" value="<?php echo $dept_name; ?>">
												</tbody><?php
												
												$count++;
											}  ?>

										</table>
										<big><p>Total Course Unit: </p></big>
									</div>
								</div>
							</div>
								
								<div class="col-sm-12" align="center">
                                <div class="md-form-group">
                                    <input type="hidden" name="show" value="<?php echo $y; ?>">
                                    
                                    <a href="" class="btn btn-success"> PRINT MY COURSE FORM
                                    </a>
                                    <a href="my-course-list.php?student-matric-number=<?php echo $student_matric_num?>&&session_identification=<?php echo $depo['session_id']; ?>" class="btn btn-warning"> MY COURSE LIST
                                    </a>

                                </div>
                            </div>
						</section>
					</div>
				</div>
				
			</div>
		</div>
	</div>
</main>

<script>
    function confirmToDelete(){
        return confirm("Click Okay to Delete Course and Cancel to Stop");
    }
</script>


<?php 
	include("../../inc/footer.php"); 
?>