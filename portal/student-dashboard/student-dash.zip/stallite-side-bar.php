<aside id="tg-sidebar" class="tg-sidebar">
	<div class="tg-widget tg-widgetcoursecategories">
		<div class="tg-widgettitle">
			<h3>Quicklinks</h3>
		</div>
		<div class="tg-widgetcontent">
			<ul>
				
				
				<li>
					<a href="">
						<span>My Assignment</span>
	                </a>
				</li>
				<li>
					<a href="">
						<span>Forum</span>
	                </a>
				</li>
				<li>
					<a href="javascript:void(0);">
						<span>Academic Calendar</span>
					</a>
				</li>
			</ul>
		</div>
	</div>
	
</aside>	