<?php 
	session_start();
	require("../../connection/connection.php");
    include("../../mgchst-administrator/super-admin/libs_dev/students-registration/students-registration.php");
    include("../../mgchst-administrator/dev/general/all_purpose_class.php");
    
    try{
    	$all_purpose = new all_purpose($db);
        $registration = new oldStudentRegistration($db);
        if(isset($_POST['admission-status'])){
            $regNumber = $all_purpose->sanitizeInput($_POST['registration']);
            if($registration->checkRegistrationNumber($regNumber)){
                $_SESSION['error'] = "Oooops!!! Registration Number $regNumber Does Not Exist";
                $all_purpose->redirect("check-admission-status.php");
            }else{
                $see = $registration->getAdmissionStepOne($regNumber);
                $admission_status = $see['admission_status'];
                if($admission_status ==1){
                    
                    $surname = $see['surname'];
                    $other_names = $see['other_names'];
                    $student_name = $surname." ".$other_names;
                    $programe = $see['prog_id'];
                    $all_purpose->redirect("print-admission-letter.php?registration_number=$regNumber&&student_name=$student_name&&programme=$programe");
                }else{
                    $_SESSION['error'] = "Sorry, No Admission For You Yet";
                    $all_purpose->redirect("check-admission-status.php");
                }
            }
        }else{
            $_SESSION['error'] = "Please Enter Your Registration Number";
            $all_purpose->redirect("check-admission-status.php");
        }

        
    }catch(PDOException $e){
    	$_SESSION['error'] = $e->getMessage();
    	$all_purpose->redirect("check-admission-status.php");
    }

?>