<?php 
	session_start(); 
	include('../../connection/connection.php');
	include("../../inc/portal-header.php"); 
	include("../../mgchst-administrator/super-admin/libs_dev/department/department-class.php");
    $department = new schoolDepartment($db);
    $proc = new programmeCourse($db);
	$department_name = $_GET['department_name'];
	$procourse_id = $_GET['identification'];
	$loyal = $proc->getProgrammeCourseIdentification($procourse_id);
	$course=$loyal;
	$dept_id = $loyal['dept_id'];
	
	$course_name = $loyal['prog_course'];
?>

<div class="tg-innerbanner">
	<div class="container">
		<div class="row">
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
				<ol class="tg-breadcrumb">
					<li><a href="./">Home</a></li>
					<li><a href="registration-form-section-one.php?programme_course=<?php echo $prog_name; ?>&&department_name=<?php echo $department_name;?>&&programme_identification=<?php echo $procourse_id; ?>">Admission Requirements</li>
					<li class="tg-active"><?php echo $department_name; ?> ADMISSION REQUIREMENTS</a></li>
				</ol>
			</div>
		</div>
	</div>
</div>
<main id="tg-main" class="tg-main tg-haslayout">
	<div class="container">
		<div class="row">
			<!-- <div class="col-md-12" align="center" style="margin-top: -10px;">
				<img src="../../images/form-logo.png" alt="../../images/form-logo.png" style="width: 950px; height: ; ">
			</div> -->
			<div id="tg-twocolumns" class="tg-twocolumns">
				<div class="col-xs-12 col-sm-8 col-md-9 col-lg-9">
					<div id="tg-content" class="tg-content">
						<section class="tg-sectionspace tg-haslayout">
							<div class="tg-borderheading">
								<h2 align="center"><?php echo "$department_name ONLINE APPLICATION FORM" ?></h2>
							</div>
							<div class="tg-events">
								<div class="row">
									<div class="col-md-12">
										<table class="table table-responsive table-bordered">
											<thead>
												<th>Course Name</th>
				                                <th> Department </th>
				                                <th>Qualification & Requirement</th>
				                                <th>Certification</th>
				                                <th>Duration</th>
				                                <th>Programme </th>
				                                
											</thead>
											<tbody>
												<tr>
													<td><?php echo $course['prog_course']; ?></td>
					                                <td><?php $dept_id= $course['dept_id']; 
					                                	$boss = $proc->DepartmentDetailsNow($dept_id);
					                                	echo $dept_name = $boss['dept_name']; ?></td>
					                                <td style="text-align: justify; text-justify: inter-word;"><?php echo $course['requirement'] ?></td>
					                                <td style="text-align: justify; text-justify: inter-word;"><?php echo $course['certification'] ?></td>
					                                <td><?php echo $duration = $course['duration'] ?></td>
					                                <td><?php 
					                                	if($duration < 4){
						                                	echo "DIPLOMA";
						                                 
						                                }else{
						                                	echo "DEGREE";
						                                }?>
					                                 	
					                                </td>
					                                
												</tr>
											</tbody>
										</table>
										<div class="col-md-12" align="center">
											
											<a href="registration-form-section-one.php?department_name=<?php echo $dept_name;?>&&programme_identification=<?php echo $procourse_id; ?>" class="btn btn-success">
											More Details and Apply Here</a>
										</div>
										
									</div>
								</div>
							</div>
						</section>
					</div>
				</div>
				<div class="col-xs-12 col-sm-4 col-md-3 col-lg-3">
					<aside id="tg-sidebar" class="tg-sidebar">
								
						<div class="tg-widget tg-widgetadmissionform">
							<div class="tg-widgetcontent">
								<h3>Admission Form 2017</h3>
								<div class="tg-description">
									<p>Interested candidates can apply online or download the application form.</p>
								</div>
								<a class="tg-btn tg-btnicon" href="online-application-form/mgchst-application-form.pdf">
									<i class="fa fa-file-pdf-o"></i>
									<span>Download PDF</span>
								</a>
							</div>
						</div>
						
						<div class="tg-widget tg-widgetsearchcourse">
							<div class="tg-widgettitle">
								<h3>Student Portal</h3>
							</div>
							<div class="tg-widgetcontent">
								<form class="tg-formtheme tg-formsearchcourse">
									<fieldset>
										<div class="tg-inputwithicon">
											<i class="icon-book"></i>
											<input type="text" name="txtusername" class="form-control" placeholder="Username">
										</div>
										<div class="tg-inputwithicon">
											<i class="icon-layers"></i>
											
											<input type="password" name="txtpassword" class="form-control" placeholder="Password">	
											
										</div>
										<button type="submit" class="tg-btn">Login</button>
										
									</fieldset>
								</form>
							</div>
						</div>
					</aside>
				</div>
			</div>
		</div>
	</div>
</main>

<?php 
	include("../../inc/footer.php"); 
?>